import { ArrowRight, Clock, Star, User, Calendar, BookOpen, TrendingUp, Calculator, Target, Lightbulb } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  publishDate: string;
  readTime: string;
  category: string;
  tags: string[];
  featured: boolean;
  image: string;
}

const blogPosts: BlogPost[] = [
  {
    id: "quadratic-formula-tricks",
    title: "5 Lightning-Fast Tricks for Solving Quadratic Equations",
    excerpt: "Master the quadratic formula and discover shortcuts that will save you precious minutes on your next math test.",
    content: `
# 5 Lightning-Fast Tricks for Solving Quadratic Equations

Quadratic equations can seem intimidating, but with the right techniques, you'll be solving them faster than you can say "discriminant"! Here are my top 5 tricks that have helped hundreds of students ace their algebra tests.

## Trick #1: The Perfect Square Shortcut

When you see equations like x² + 6x + 9 = 0, don't reach for the quadratic formula just yet! This is a perfect square trinomial: (x + 3)² = 0.

**Quick Recognition Pattern:**
- Check if the middle term is 2√(first term × last term)
- If yes, you have a perfect square!

## Trick #2: Factor by Grouping Method

For equations like x² + 5x + 6 = 0, think: "What two numbers multiply to 6 and add to 5?"
Answer: 2 and 3, so (x + 2)(x + 3) = 0

## Trick #3: The Discriminant Prediction

Before solving, calculate b² - 4ac:
- Positive = 2 real solutions
- Zero = 1 real solution
- Negative = no real solutions

This saves time by telling you what to expect!

## Trick #4: Complete the Square Visually

Transform x² + bx into (x + b/2)² - (b/2)²
This method helps you "see" the solution and builds intuition for vertex form.

## Trick #5: The AC Method for Tough Cases

When traditional factoring fails, use the AC method:
1. Multiply 'a' and 'c' coefficients
2. Find factors of AC that add to 'b'
3. Split the middle term and factor by grouping

**Practice Problem:** Try 2x² + 7x + 3 = 0
AC = 6, factors are 6 and 1 (since 6 + 1 = 7)
2x² + 6x + x + 3 = 2x(x + 3) + 1(x + 3) = (2x + 1)(x + 3)

These tricks will transform your quadratic equation solving from struggle to success!
    `,
    author: "Luka",
    publishDate: "2024-01-15",
    readTime: "8 min read",
    category: "Algebra",
    tags: ["quadratic equations", "factoring", "algebra tips"],
    featured: true,
    image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
  },
  {
    id: "geometry-memory-tricks",
    title: "Geometry Formulas You'll Never Forget: Memory Tricks That Actually Work",
    excerpt: "Stop memorizing formulas the hard way! These visual memory tricks will help you remember geometry formulas effortlessly.",
    content: `
# Geometry Formulas You'll Never Forget: Memory Tricks That Actually Work

Struggling to remember whether it's πr² or 2πr? These memory tricks will make geometry formulas stick in your brain like mathematical superglue!

## Circle Formulas Made Simple

**Area of a Circle: A = πr²**
Memory trick: "Pies are round, so π × radius × radius for the area!"

**Circumference: C = 2πr or C = πd**
Memory trick: "Circumference goes around (like a crown), so it's 2π times the radius"

## Triangle Area Shortcuts

**Area = ½ × base × height**
Memory trick: "Half the rectangle that the triangle fits in"

**For right triangles:** Remember the 3-4-5 rule and its multiples (6-8-10, 9-12-15)

## Pythagorean Theorem: a² + b² = c²

Memory tricks:
- "A squared plus B squared equals C squared" (sing it to a tune!)
- Visual: Draw squares on each side of a right triangle

## Volume Formulas

**Cylinder: V = πr²h**
Memory trick: "Cylinder = Circle area × height (stack circles up!)"

**Cone: V = ⅓πr²h**  
Memory trick: "A cone is ⅓ of a cylinder with the same base and height"

**Sphere: V = ⅘πr³**
Memory trick: "Four-thirds of π, radius cubed - it's the only sphere formula!"

## Angle Relationships

- Complementary angles add to 90° (think "Completes a corner")
- Supplementary angles add to 180° (think "Supplement to a straight line")
- Vertical angles are equal (they look at each other across an X)

## Pro Tips for Test Day

1. Draw diagrams for EVERYTHING
2. Label what you know and what you need to find
3. Look for special triangles (30-60-90, 45-45-90)
4. Remember: geometry is visual - if you can see it, you can solve it!

Practice these memory tricks daily, and watch your geometry confidence skyrocket!
    `,
    author: "Luka",
    publishDate: "2024-01-08",
    readTime: "6 min read",
    category: "Geometry",
    tags: ["geometry", "memory tricks", "formulas"],
    featured: true,
    image: "https://images.unsplash.com/photo-1509228468518-180dd4864904?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
  },
  {
    id: "sat-math-pitfalls",
    title: "Top 10 SAT Math Mistakes (And How to Avoid Them)",
    excerpt: "Don't let these common SAT math pitfalls tank your score. Learn what trips up most students and how to stay ahead.",
    content: `
# Top 10 SAT Math Mistakes (And How to Avoid Them)

After tutoring hundreds of students for the SAT, I've seen the same mistakes over and over. Here are the top 10 pitfalls and exactly how to avoid them.

## Mistake #1: Not Reading the Question Carefully

**The Problem:** Rushing through questions and missing key details
**Example:** Question asks for 2x but you solve for x
**Solution:** Circle what the question is asking for before you start solving

## Mistake #2: Forgetting to Check Your Answer

**The Problem:** Getting the math right but choosing the wrong answer choice
**Solution:** Always substitute your answer back into the original equation

## Mistake #3: Calculator Dependency

**The Problem:** Reaching for the calculator on problems designed to be solved mentally
**Example:** 15% of 80 (should be 12, not a calculator problem!)
**Solution:** Practice mental math daily

## Mistake #4: Misreading Graphs and Charts

**The Problem:** Not paying attention to axis labels, scales, or units
**Solution:** Always check what each axis represents and what units are used

## Mistake #5: Algebra Shortcuts Gone Wrong

**The Problem:** Making sign errors when distributing or combining like terms
**Most Common:** -(x - 3) becomes -x - 3 instead of -x + 3
**Solution:** Write out each step completely, especially with negative signs

## Mistake #6: Geometry Assumption Errors

**The Problem:** Assuming figures are drawn to scale (they're not!)
**Solution:** Only use given measurements and proven relationships

## Mistake #7: Word Problem Translation Errors

**The Problem:** Misinterpreting "is," "of," "more than," and "less than"
**Key Translations:**
- "is" = equals (=)
- "of" = multiply (×)
- "more than" = add (+)
- "less than" = subtract (-, but watch the order!)

## Mistake #8: Time Management Disasters

**The Problem:** Spending too much time on hard questions early on
**Solution:** Do a first pass answering all easy/medium questions, then return to harder ones

## Mistake #9: Not Using Process of Elimination

**The Problem:** Trying to solve every question from scratch
**Strategy:** On multiple choice, eliminate obviously wrong answers first

## Mistake #10: Panic Mode Problem-Solving

**The Problem:** Getting stuck and panicking instead of using strategic guessing
**Solution:** Learn when to make an educated guess and move on

## Your SAT Math Action Plan

1. **Practice under timed conditions** regularly
2. **Keep an error log** - track your mistakes and review them weekly
3. **Master the calculator policy** - know when to use it and when not to
4. **Learn the common question types** - there are only about 15 different problem types on the SAT
5. **Focus on accuracy over speed** initially, then build up speed

Remember: The SAT rewards careful, strategic thinking more than pure mathematical genius. Avoid these pitfalls, and watch your score improve!
    `,
    author: "Luka",
    publishDate: "2024-01-01",
    readTime: "10 min read",
    category: "Test Prep",
    tags: ["SAT", "test prep", "common mistakes"],
    featured: true,
    image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
  },
  {
    id: "calculus-limits-intuition",
    title: "Understanding Limits: Building Intuition Before the Formulas",
    excerpt: "Limits don't have to be mysterious. Build rock-solid intuition that makes advanced calculus concepts crystal clear.",
    content: `
# Understanding Limits: Building Intuition Before the Formulas

Limits are the foundation of all calculus, yet most students jump straight to memorizing rules without understanding what's actually happening. Let's build that intuition first!

## What IS a Limit, Really?

Think of a limit as asking: "What value is this function approaching as x gets closer and closer to some number?"

**Real-world analogy:** Imagine driving toward your house. As you get closer and closer to your driveway, where are you headed? That's the limit!

## Visualization is Everything

### Example 1: The Hole in the Graph
Consider f(x) = (x² - 1)/(x - 1)

At x = 1, we get 0/0 (undefined). But what happens as x approaches 1?
- When x = 1.1: f(x) = 2.1
- When x = 1.01: f(x) = 2.01  
- When x = 1.001: f(x) = 2.001

The limit as x approaches 1 is 2, even though f(1) doesn't exist!

## The Three Types of Limits

### 1. The Limit Exists and Equals the Function Value
This is the "nice" case where everything works as expected.

### 2. The Limit Exists but Doesn't Equal the Function Value  
This happens with removable discontinuities (holes in the graph).

### 3. The Limit Doesn't Exist
This occurs when:
- The function approaches different values from left and right
- The function grows without bound (infinite limits)
- The function oscillates wildly

## Common Limit Techniques

### Direct Substitution (Try This First!)
If plugging in the value gives you a number (not 0/0 or ∞/∞), you're done!

### Factoring Method
For 0/0 forms, factor and cancel common terms.

### Rationalization
For limits involving square roots, multiply by the conjugate.

### Squeeze Theorem
When a function is "squeezed" between two others that approach the same limit.

## Building Intuition Through Practice

**Exercise:** Before calculating, predict what happens:

1. lim(x→2) (x² + 3x - 1)
   *Intuition: Direct substitution should work*

2. lim(x→0) sin(x)/x  
   *Intuition: Both numerator and denominator approach 0*

3. lim(x→∞) (3x² + 2x)/(x² - 1)
   *Intuition: Both grow large, but what dominates?*

## Why This Matters for Advanced Calculus

Understanding limits deeply helps with:
- **Derivatives:** They're limits of difference quotients
- **Integrals:** They're limits of Riemann sums  
- **Series:** They're limits of partial sums
- **Continuity:** Defined using limits

## Pro Tips for Limit Success

1. **Always sketch or visualize first**
2. **Look for patterns in the behavior**
3. **Check from both sides of the point**
4. **Don't rush to formulas - understand the concept**
5. **Practice with different types regularly**

Remember: Limits are about behavior and trends, not just plugging into formulas. Master the intuition, and calculus becomes much more manageable!
    `,
    author: "Luka",
    publishDate: "2023-12-20",
    readTime: "12 min read",
    category: "Calculus",
    tags: ["calculus", "limits", "intuition"],
    featured: false,
    image: "https://images.unsplash.com/photo-1596495577886-d920f1fb7238?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
  },
  {
    id: "word-problems-strategy",
    title: "Word Problems Decoded: A Step-by-Step Strategy That Works",
    excerpt: "Transform word problem anxiety into confidence with this proven 5-step method that works for any math level.",
    content: `
# Word Problems Decoded: A Step-by-Step Strategy That Works

Word problems strike fear into the hearts of math students everywhere. But here's the secret: they're just regular math problems wearing a disguise. Let's unmask them!

## The Universal 5-Step Strategy

### Step 1: Read and Understand
- Read the problem twice (minimum!)
- Identify what's happening in the story
- Ask: "What is this problem really about?"

### Step 2: Identify and Define Variables
- What are you looking for? (This becomes your variable)
- What information are you given?
- Write clear definitions: "Let x = the number of apples"

### Step 3: Translate Words to Math
**Common Translation Patterns:**
- "is/was/will be" → =
- "of" → × (multiply)
- "more than" → +
- "less than" → - (watch the order!)
- "times as much" → ×

### Step 4: Solve the Equation
Use your regular algebra skills here.

### Step 5: Check and Interpret
- Does your answer make sense in context?
- Answer the original question completely
- Include appropriate units

## Real Examples in Action

### Example 1: Age Problem
"Sarah is 3 years older than twice her brother's age. If Sarah is 15, how old is her brother?"

**Step 1:** Sarah's age relates to her brother's age
**Step 2:** Let x = brother's age. Given: Sarah is 15
**Step 3:** Sarah's age = 2x + 3, so 15 = 2x + 3
**Step 4:** 12 = 2x, so x = 6
**Step 5:** Brother is 6 years old. Check: 2(6) + 3 = 15 ✓

### Example 2: Distance Problem  
"Two cars leave the same point traveling in opposite directions. One travels 60 mph, the other 70 mph. How long until they're 390 miles apart?"

**Step 1:** Cars moving apart, combined distance = 390 miles
**Step 2:** Let t = time in hours
**Step 3:** Distance = rate × time, so 60t + 70t = 390
**Step 4:** 130t = 390, so t = 3
**Step 5:** After 3 hours. Check: 60(3) + 70(3) = 180 + 210 = 390 ✓

### Example 3: Mixture Problem
"How many gallons of 20% salt solution must be mixed with 5 gallons of 60% salt solution to create a 40% solution?"

**Step 1:** Mixing solutions with different concentrations
**Step 2:** Let x = gallons of 20% solution
**Step 3:** 0.20x + 0.60(5) = 0.40(x + 5)
**Step 4:** 0.20x + 3 = 0.40x + 2, so 1 = 0.20x, so x = 5
**Step 5:** Need 5 gallons of 20% solution

## Common Word Problem Types & Patterns

### 1. Age Problems
Pattern: Current ages with relationships

### 2. Distance/Rate/Time  
Pattern: d = rt, often with objects moving toward/away from each other

### 3. Work Problems
Pattern: Combined work rates

### 4. Mixture Problems
Pattern: Amount × concentration = pure substance

### 5. Money/Interest Problems
Pattern: Principal × rate × time = interest

### 6. Geometry Applications
Pattern: Perimeter, area, or volume formulas with constraints

## Troubleshooting Common Mistakes

**Mistake:** "I don't know where to start"
**Fix:** Always start by defining what you're looking for

**Mistake:** "The numbers don't make sense"  
**Fix:** Re-read the problem; you might have missed a detail

**Mistake:** "I got a negative answer for someone's age"
**Fix:** Check your equation setup; you might have the relationship backwards

## Advanced Tips for Complex Problems

1. **Draw diagrams** for geometry or motion problems
2. **Make tables** for organizing information in rate/mixture problems
3. **Use multiple variables** when necessary, but solve systematically
4. **Break complex problems** into smaller parts
5. **Practice specific types** until you recognize patterns

## Building Word Problem Confidence

Start with easier problems and gradually increase complexity. Remember:
- Every word problem follows these same 5 steps
- The math is usually simpler than the reading comprehension
- Practice makes perfect - the more you do, the faster you'll recognize patterns

Word problems aren't math problems with extra steps - they're real-world applications that make math meaningful!
    `,
    author: "Luka",
    publishDate: "2023-12-15",
    readTime: "9 min read",
    category: "Problem Solving",
    tags: ["word problems", "strategy", "algebra"],
    featured: false,
    image: "https://images.unsplash.com/photo-1553884349-0ad1c4fedc9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
  },
  {
    id: "trigonometry-unit-circle",
    title: "The Unit Circle: Your Secret Weapon for Trigonometry Success",
    excerpt: "Master the unit circle once, and unlock all of trigonometry. Here's how to build it from scratch and use it effectively.",
    content: `
# The Unit Circle: Your Secret Weapon for Trigonometry Success

The unit circle is trigonometry's ultimate cheat sheet. Master it once, and you'll never struggle with trig functions again. Let's build one together!

## What Makes the Unit Circle So Powerful?

The unit circle is simply a circle with radius 1 centered at the origin. But it encodes ALL the information about sine, cosine, and tangent for any angle. Here's why it's amazing:

- **One diagram contains infinite information**
- **Connects algebra and geometry**  
- **Makes trig identities obvious**
- **Simplifies complex calculations**

## Building Your Unit Circle from Scratch

### Step 1: Start with the Basics
- Circle with radius 1 at origin (0,0)
- Any point on the circle is (cos θ, sin θ)
- This means x² + y² = 1 always!

### Step 2: The Special Right Triangles
Master these two triangles:

**45-45-90 Triangle:**
- Sides in ratio 1:1:√2
- At 45°: cos = sin = √2/2

**30-60-90 Triangle:**  
- Sides in ratio 1:√3:2
- At 30°: cos = √3/2, sin = 1/2
- At 60°: cos = 1/2, sin = √3/2

### Step 3: The Key Angles (in degrees and radians)
- 0° (0): (1, 0)
- 30° (π/6): (√3/2, 1/2)  
- 45° (π/4): (√2/2, √2/2)
- 60° (π/3): (1/2, √3/2)
- 90° (π/2): (0, 1)

### Step 4: Extend to All Four Quadrants
Use the patterns:
- **Quadrant I:** Both positive
- **Quadrant II:** x negative, y positive  
- **Quadrant III:** Both negative
- **Quadrant IV:** x positive, y negative

## Memory Tricks That Actually Work

### The "All Students Take Calculus" Method
- **A**ll (Quadrant I): All trig functions positive
- **S**tudents (Quadrant II): Only Sine positive
- **T**ake (Quadrant III): Only Tangent positive  
- **C**alculus (Quadrant IV): Only Cosine positive

### The Coordinate Pattern
For reference angles 30°, 45°, 60°:

**Sine values:** 1/2, √2/2, √3/2 (increasing)
**Cosine values:** √3/2, √2/2, 1/2 (decreasing)

Notice they're opposites of each other!

### The Fraction Pattern
All unit circle values are either:
- 0, 1, or -1
- ±1/2, ±√2/2, or ±√3/2

## Practical Applications

### Finding Exact Values
**Example:** Find sin(150°)

1. 150° is in Quadrant II (sine positive)
2. Reference angle: 180° - 150° = 30°
3. sin(30°) = 1/2
4. Therefore: sin(150°) = 1/2

### Solving Trig Equations
**Example:** Solve cos x = -1/2

1. Find where cosine equals 1/2: at 60° and 300°
2. Since we need -1/2, we need Quadrants II and III
3. Solutions: 120° and 240° (plus any full rotations)

### Graphing Trig Functions
The unit circle coordinates directly give you points on sine and cosine graphs!

## Advanced Unit Circle Strategies

### 1. Beyond Special Angles
Use the unit circle to understand behavior between special angles.

### 2. Negative Angles  
Move clockwise instead of counterclockwise.

### 3. Angles Greater than 360°
Find the coterminal angle by subtracting multiples of 360°.

### 4. Connecting to Identities
See why sin²θ + cos²θ = 1 (it's just the Pythagorean theorem!)

## Common Student Mistakes to Avoid

1. **Confusing coordinates:** Remember (cos θ, sin θ), not (sin θ, cos θ)
2. **Sign errors:** Pay attention to which quadrant you're in
3. **Degree vs. radian confusion:** Know both and convert accurately
4. **Memorizing without understanding:** Build it, don't just memorize it

## Your Unit Circle Action Plan

**Week 1:** Master the first quadrant special angles
**Week 2:** Extend to all four quadrants  
**Week 3:** Practice finding exact values
**Week 4:** Apply to equation solving and graphing

## Pro Tips for Test Success

1. **Sketch it quickly** - draw a rough unit circle on tests
2. **Start with what you know** - use reference angles
3. **Check your signs** - quadrant determines positive/negative
4. **Practice mental rotation** - visualize moving around the circle

The unit circle isn't just a tool - it's the key that unlocks all of trigonometry. Master it, and watch your trig confidence soar!
    `,
    author: "Luka",
    publishDate: "2023-12-10",
    readTime: "11 min read",
    category: "Trigonometry",
    tags: ["trigonometry", "unit circle", "special angles"],
    featured: false,
    image: "https://images.unsplash.com/photo-1635070041409-e63e783d4023?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
  }
];

export default function ResourcesPage() {
  const featuredPosts = blogPosts.filter(post => post.featured);
  const regularPosts = blogPosts.filter(post => !post.featured);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary via-primary/90 to-primary/60 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Math Resources & Study Guides
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Free guides, tips, and strategies to help you master math concepts and ace your tests. 
              From algebra basics to calculus mastery - everything you need is here!
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-blue-100">
              <div className="flex items-center">
                <BookOpen className="w-5 h-5 mr-2" />
                <span>20+ In-depth Guides</span>
              </div>
              <span>•</span>
              <div className="flex items-center">
                <Target className="w-5 h-5 mr-2" />
                <span>Test-Taking Strategies</span>
              </div>
              <span>•</span>
              <div className="flex items-center">
                <Lightbulb className="w-5 h-5 mr-2" />
                <span>Memory Tricks</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">Featured Guides</h2>
            <p className="text-xl text-slate-600">Our most popular and effective study guides</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {featuredPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-xl transition-shadow overflow-hidden">
                <div className="relative">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-48 object-cover"
                  />
                  <Badge className="absolute top-4 left-4 bg-yellow-400 text-slate-800">
                    Featured
                  </Badge>
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between text-sm text-slate-500 mb-2">
                    <span className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {new Date(post.publishDate).toLocaleDateString()}
                    </span>
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {post.readTime}
                    </span>
                  </div>
                  <CardTitle className="text-xl mb-2">{post.title}</CardTitle>
                  <Badge variant="outline" className="w-fit">
                    {post.category}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-4">{post.excerpt}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {post.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <button className="text-blue-600 font-semibold flex items-center hover:underline">
                    Read Full Guide <ArrowRight className="w-4 h-4 ml-1" />
                  </button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Study Categories */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">Browse by Subject</h2>
            <p className="text-xl text-slate-600">Find exactly what you need to study</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { 
                title: "Algebra", 
                count: "8 guides", 
                icon: Calculator, 
                description: "From basic equations to advanced polynomials",
                color: "bg-blue-600"
              },
              { 
                title: "Geometry", 
                count: "6 guides", 
                icon: Target, 
                description: "Shapes, proofs, and spatial reasoning",
                color: "bg-emerald-600"
              },
              { 
                title: "Trigonometry", 
                count: "5 guides", 
                icon: TrendingUp, 
                description: "Unit circle, identities, and applications",
                color: "bg-yellow-600"
              },
              { 
                title: "Calculus", 
                count: "4 guides", 
                icon: Lightbulb, 
                description: "Limits, derivatives, and integrals",
                color: "bg-purple-600"
              }
            ].map((category, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6 text-center">
                  <div className={`${category.color} text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <category.icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{category.title}</h3>
                  <p className="text-slate-600 mb-2">{category.description}</p>
                  <p className="text-sm text-slate-500 font-medium">{category.count}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* All Blog Posts */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">All Study Guides</h2>
            <p className="text-xl text-slate-600">Comprehensive resources for every math topic</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-40 object-cover rounded-t-lg"
                  />
                  {post.featured && (
                    <Badge className="absolute top-3 left-3 bg-yellow-400 text-slate-800">
                      Featured
                    </Badge>
                  )}
                </div>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between text-sm text-slate-500 mb-2">
                    <Badge variant="outline">{post.category}</Badge>
                    <span className="flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      {post.readTime}
                    </span>
                  </div>
                  <CardTitle className="text-lg leading-tight">{post.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 text-sm mb-3 line-clamp-3">{post.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-slate-500">
                      <User className="w-3 h-3 mr-1" />
                      {post.author}
                    </div>
                    <button className="text-blue-600 text-sm font-semibold hover:underline">
                      Read More
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20 bg-gradient-to-r from-slate-800 via-slate-700 to-slate-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Get New Study Guides Delivered</h2>
          <p className="text-xl mb-8 text-slate-300">
            Be the first to know when we publish new math guides and study tips!
          </p>
          
          <div className="max-w-md mx-auto">
            <div className="flex gap-3">
              <input 
                type="email" 
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
              <button className="bg-yellow-400 text-slate-800 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors">
                Subscribe
              </button>
            </div>
            <p className="text-sm text-slate-400 mt-3">
              No spam, unsubscribe anytime. Just helpful math content!
            </p>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-slate-800 mb-6">
            Need Personalized Help?
          </h2>
          <p className="text-xl text-slate-600 mb-8">
            These guides are great, but sometimes you need one-on-one support. 
            Let's work together to tackle your specific math challenges!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
              onClick={() => scrollToSection('contact')}
            >
              Book Free Trial Session
            </button>
            <button className="bg-slate-200 text-slate-800 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-slate-300 transition-colors">
              View Tutoring Plans
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}