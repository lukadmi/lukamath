import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import ServicesSection from "@/components/services-section";
import TestimonialsSection from "@/components/testimonials-section";
import PricingSection from "@/components/pricing-section";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calculator, Users, Calendar, TrendingUp, Star, ArrowRight, Clock, Shield, CheckCircle } from "lucide-react";

export default function Home() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />
      <HeroSection />
      {/* Why LukaMath Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">Why Luka?</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">Stop letting math stress you out. With expert guidance, flexible scheduling, and proven methods, we make complex concepts crystal clear.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-6 bg-slate-50 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-2">Expert High-School Tutor</h3>
                <p className="text-slate-600">5+ years teaching experience with proven track record</p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6 bg-slate-50 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 bg-[#e8e854]">
                  <Calendar className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-2">Flexible Scheduling</h3>
                <p className="text-slate-600">Book sessions that fit your busy life, 7 days a week</p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6 bg-slate-50 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-slate-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 bg-[#fccd42]">
                  <Calculator className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-2">Interactive Whiteboard</h3>
                <p className="text-slate-600">Real-time collaboration with digital tools and visual aids</p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6 bg-slate-50 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="bg-emerald-500 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-2">Proven Score Gains</h3>
                <p className="text-slate-600">Average 15% improvement in test scores within 8 sessions</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      <ServicesSection />
      {/* How It Works Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">How It Works</h2>
            <p className="text-xl text-slate-600">Getting started is as easy as 1-2-3!</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold bg-[#91bcff]">1</div>
              <h3 className="text-2xl font-bold mb-4">Pick a Package and Schedule</h3>
              <p className="text-slate-600 mb-4">Choose your subject and book a time that works for you</p>
              <img 
                src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Student scheduling online session" 
                className="rounded-lg shadow-md w-full"
              />
            </div>
            
            <div className="text-center text-[#ffffff]">
              <div className="text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold bg-[#2094f3]">2</div>
              <h3 className="text-2xl font-bold mb-4 text-[#0c0a09]">Join Zoom + Shared Whiteboard</h3>
              <p className="text-slate-600 mb-4">Connect online with interactive tools for real-time collaboration</p>
              <img 
                src="https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Online learning video call setup" 
                className="rounded-lg shadow-md w-full"
              />
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold text-[#ffffff] bg-[#0051b8]">3</div>
              <h3 className="text-2xl font-bold mb-4">Master Concepts and Track Progress</h3>
              <p className="text-slate-600 mb-4">Build understanding step-by-step with personalized feedback</p>
              <img 
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Successful student with math books" 
                className="rounded-lg shadow-md w-full"
              />
            </div>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-lg text-slate-600 font-medium">No more guessing - get real-time feedback.</p>
          </div>
        </div>
      </section>
      {/* About Luka Section */}
      <section id="about" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600" 
                alt="Luka - Professional Math Tutor" 
                className="rounded-2xl shadow-xl w-full max-w-md mx-auto"
              />
            </div>
            <div>
              <h2 className="text-4xl font-bold text-slate-800 mb-6">Meet Luka</h2>
              <div className="text-lg text-slate-600 space-y-4 mb-8">
                <p>
                  <strong>M.S. in Data Science, Illinois Institute of Technology</strong> | 5+ years of tutoring experience
                </p>
                <p>
                  I believe every student can excel in math with the right approach and encouragement. 
                  My goal is to make complex concepts feel simple and help you build genuine confidence.
                </p>
                <p>
                  When I'm not solving equations, you'll find me rock climbing or perfecting my chess game. 
                  <em>Fun fact: I have over 100 math puns in my arsenal—but don't worry, I use them sparingly! 📐</em>
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <div className="bg-white px-4 py-2 rounded-full text-sm font-semibold text-slate-700">
                  <Users className="w-4 h-4 inline text-primary mr-2" />
                  Stanford Graduate
                </div>
                <div className="bg-white px-4 py-2 rounded-full text-sm font-semibold text-slate-700">
                  <Users className="w-4 h-4 inline text-secondary mr-2" />
                  200+ Students Helped
                </div>
                <div className="bg-white px-4 py-2 rounded-full text-sm font-semibold text-slate-700">
                  <Star className="w-4 h-4 inline text-accent mr-2" />
                  4.9/5 Rating
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <TestimonialsSection />
      <PricingSection />
      {/* Free Resources Section */}
      <section id="resources" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">Free Math Resources</h2>
            <p className="text-xl text-slate-600">Boost your skills with these helpful guides and tips</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="bg-slate-50 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <img 
                  src="https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                  alt="Mathematical equations and formulas" 
                  className="rounded-lg mb-6 w-full"
                />
                <h3 className="text-xl font-bold mb-3">5 Fast Tricks for Quadratic Equations</h3>
                <p className="text-slate-600 mb-4">Master the quadratic formula and factoring techniques that save time on tests.</p>
                <Button variant="link" className="text-primary p-0 h-auto font-semibold">
                  Read More <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-50 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <img 
                  src="https://images.unsplash.com/photo-1509228468518-180dd4864904?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                  alt="Geometric shapes and mathematical diagrams" 
                  className="rounded-lg mb-6 w-full"
                />
                <h3 className="text-xl font-bold mb-3">Geometry Hacks That Save You Time on Tests</h3>
                <p className="text-slate-600 mb-4">Learn the shortcuts and memory tricks that make geometry problems click.</p>
                <Button variant="link" className="text-secondary p-0 h-auto font-semibold">
                  Read More <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-50 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <img 
                  src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                  alt="SAT prep materials and study guides" 
                  className="rounded-lg mb-6 w-full"
                />
                <h3 className="text-xl font-bold mb-3">Top 10 SAT Math Pitfalls and How to Avoid Them</h3>
                <p className="text-slate-600 mb-4">Common mistakes that trip up test-takers and strategies to avoid them.</p>
                <Button variant="link" className="text-accent p-0 h-auto font-semibold">
                  Read More <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center">
            <Button variant="link" className="text-primary font-semibold text-lg p-0 h-auto">
              See all resources <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>
      {/* Final CTA Section */}
      <section className="py-20 bg-gradient-to-r from-slate-800 via-slate-700 to-slate-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Crush Your Next Math Test?</h2>
          <p className="text-xl mb-8 text-blue-100">
            Don't let math anxiety hold you back. Start your journey to mathematical confidence today!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-accent text-slate-800 hover:bg-yellow-400 text-lg px-8 py-4 h-auto"
              onClick={() => scrollToSection('contact')}
            >
              <Calendar className="w-5 h-5 mr-2" />
              Book Your Free 30-Min Trial
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-white/20 text-white border-white/30 hover:bg-white/30 text-lg px-8 py-4 h-auto backdrop-blur-sm"
            >
              <Clock className="w-5 h-5 mr-2" />
              Call (555) 123-MATH
            </Button>
          </div>
          <p className="mt-6 text-blue-100 flex items-center justify-center gap-2">
            <Clock className="w-4 h-4" />
            Free trial • No credit card required • 100% satisfaction guaranteed
          </p>
        </div>
      </section>
      <Footer />
    </div>
  );
}
