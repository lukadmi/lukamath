import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Shield } from "lucide-react";

export default function PricingSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const plans = [
    {
      name: "Single Session",
      price: "$50",
      period: "per 60-minute session",
      features: [
        "60-minute one-on-one session",
        "Interactive whiteboard access", 
        "Personalized practice problems",
        "Session notes & summary"
      ],
      buttonText: "Book Single Session",
      buttonVariant: "outline" as const
    },
    {
      name: "5-Session Bundle",
      price: "$225", 
      period: "10% off - $45 per session",
      features: [
        "5 × 60-minute sessions",
        "Progress tracking & reports",
        "Email support between sessions", 
        "Flexible rescheduling"
      ],
      buttonText: "Get Started",
      buttonVariant: "default" as const,
      isPopular: true
    },
    {
      name: "Monthly Plan",
      price: "$160",
      period: "4 sessions + priority booking", 
      features: [
        "4 × 60-minute sessions",
        "Priority booking access",
        "Monthly progress review",
        "Free makeup sessions"
      ],
      buttonText: "Choose Monthly",
      buttonVariant: "outline" as const
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Simple, Fair Pricing</h2>
          <p className="text-xl text-slate-600">Choose the package that fits your goals and schedule</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index}
              className={`bg-white shadow-lg relative ${plan.isPopular ? 'border-2 border-primary shadow-xl' : ''}`}
            >
              {plan.isPopular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary text-white px-6 py-2">
                    Most Popular
                  </Badge>
                </div>
              )}
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold mb-4">{plan.name}</h3>
                  <div className={`text-5xl font-bold mb-2 ${plan.isPopular ? 'text-primary' : 'text-slate-800'}`}>
                    {plan.price}
                  </div>
                  <div className="text-slate-500">{plan.period}</div>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="w-5 h-5 text-secondary mr-3" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full ${plan.isPopular ? 'bg-primary hover:bg-blue-700' : plan.buttonVariant === 'outline' ? 'bg-slate-200 text-slate-800 hover:bg-slate-300' : ''}`}
                  variant={plan.isPopular ? 'default' : plan.buttonVariant}
                  onClick={scrollToContact}
                >
                  {plan.buttonText}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-slate-600 font-medium flex items-center justify-center gap-2">
            <Shield className="w-5 h-5 text-secondary" />
            Money-back guarantee if you're not thrilled after your first session!
          </p>
        </div>
      </div>
    </section>
  );
}