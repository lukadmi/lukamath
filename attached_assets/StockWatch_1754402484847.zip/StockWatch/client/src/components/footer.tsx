import { Calculator, Mail, Phone, Clock, Facebook, Twitter, Instagram, Youtube } from "lucide-react";
import ContactForm from "./contact-form";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <>
      <ContactForm />
      <footer className="bg-slate-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold mb-4 flex items-center">
                <Calculator className="w-8 h-8 mr-2" />
                LukaMath
              </div>
              <p className="text-slate-300 mb-4">
                Making math simple, one student at a time.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-slate-300 hover:text-white transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="#" className="text-slate-300 hover:text-white transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="text-slate-300 hover:text-white transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="#" className="text-slate-300 hover:text-white transition-colors">
                  <Youtube className="w-5 h-5" />
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li><a href="#" className="hover:text-white transition-colors">Algebra Tutoring</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Geometry Help</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Calculus Support</a></li>
                <li><a href="#" className="hover:text-white transition-colors">SAT/ACT Prep</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-slate-300">
                <li><a href="#" className="hover:text-white transition-colors">Free Practice Tests</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Study Guides</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Math Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Video Tutorials</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-slate-300">
                <li className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  hello@lukamath.com
                </li>
                <li className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  (555) 123-MATH
                </li>
                <li className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  Mon-Sun: 9AM-9PM PST
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-700 mt-12 pt-8 text-center text-slate-300">
            <p>&copy; {currentYear} LukaMath. All rights reserved. | Privacy Policy | Terms of Service</p>
          </div>
        </div>
      </footer>
    </>
  );
}