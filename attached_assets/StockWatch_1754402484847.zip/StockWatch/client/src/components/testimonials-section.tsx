import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: "Sarah M.",
      role: "Parent, Junior Student",
      text: "After 8 sessions with Luka, my daughter went from a C to an A in Algebra II! His patience and clear explanations made all the difference.",
      avatar: "S",
      bgColor: "bg-primary"
    },
    {
      name: "Marcus T.",
      role: "High School Senior", 
      text: "I raised my SAT math score by 120 points in just 2 months! Luka's test strategies and practice problems were exactly what I needed.",
      avatar: "M",
      bgColor: "bg-secondary"
    },
    {
      name: "Amy L.",
      role: "Sophomore Student",
      text: "Geometry used to give me nightmares. Now I actually enjoy solving proofs! Luka has a gift for making complex topics simple.",
      avatar: "A", 
      bgColor: "bg-accent"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Success Stories That Add Up</h2>
          <p className="text-xl text-slate-600">Real students, real results, real confidence boost</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-slate-50">
              <CardContent className="p-8">
                <div className="flex text-accent mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-slate-700 mb-6 italic">
                  "{testimonial.text}"
                </p>
                <div className="flex items-center">
                  <div className={`w-12 h-12 ${testimonial.bgColor} rounded-full flex items-center justify-center text-white font-bold mr-4`}>
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-slate-500">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Score Improvement Stats */}
        <div className="from-slate-800 via-slate-700 to-slate-600 p-8 rounded-2xl text-white text-center bg-[#4655e8]">
          <h3 className="text-2xl font-bold mb-6">Average Score Improvements</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="text-4xl font-bold mb-2">78% → 92%</div>
              <div className="text-blue-100">Class Test Averages</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">+120pts</div>
              <div className="text-blue-100">SAT Math Scores</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">95%</div>
              <div className="text-blue-100">Student Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}