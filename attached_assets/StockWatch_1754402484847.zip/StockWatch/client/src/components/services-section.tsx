import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function ServicesSection() {
  const services = [
    {
      title: "Algebra I & II",
      description: "Master equations, functions, and problem-solving strategies",
      price: "$45/hr",
      tagline: "Build your foundation strong",
      icon: "√",
      bgColor: "bg-primary",
      textColor: "text-primary"
    },
    {
      title: "Geometry & Trigonometry", 
      description: "Visualize concepts and ace those proofs",
      price: "$50/hr",
      tagline: "Get the right angle on math",
      icon: "△",
      bgColor: "bg-secondary",
      textColor: "text-secondary"
    },
    {
      title: "Pre-Calculus & Calculus",
      description: "Tackle limits, derivatives, and integrals with confidence", 
      price: "$55/hr",
      tagline: "Reach your limit... then exceed it",
      icon: "∞",
      bgColor: "bg-accent",
      textColor: "text-accent"
    },
    {
      title: "SAT/ACT Math Bootcamp",
      description: "Test strategies and practice for your best score",
      price: "$60/hr", 
      tagline: "Most Popular",
      icon: "🏆",
      bgColor: "bg-primary",
      textColor: "text-primary",
      isPopular: true
    }
  ];

  return (
    <section id="services" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Math Made Simple</h2>
          <p className="text-xl text-slate-600">From basic algebra to advanced calculus, I've got you covered!</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index}
              className={`bg-white hover:shadow-xl transition-shadow ${service.isPopular ? 'border-2 border-primary' : ''}`}
            >
              <CardContent className="p-8">
                <div className="mb-4 text-4xl font-bold text-[#2094f3]">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-bold mb-3">{service.title}</h3>
                <p className="text-slate-600 mb-4">{service.description}</p>
                <div className="text-2xl font-bold mb-2 text-[#1e93f3]">
                  {service.price}
                </div>
                <p className={`text-sm ${service.isPopular ? 'font-semibold' : 'text-slate-500'}`}>
                  {service.tagline}
                </p>
                {service.isPopular && (
                  <Badge className="mt-2 bg-primary text-white">
                    Most Popular!
                  </Badge>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}