import { Button } from "@/components/ui/button";
import { Play, Video, Star } from "lucide-react";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="bg-gradient-to-r from-primary via-primary/90 to-primary/60 text-white py-20 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 via-transparent to-blue-600/5"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Ace Your Math Tests—
              <span className="text-accent">One Problem at a Time</span>
            </h1>
            <p className="text-xl mb-8 text-blue-100 leading-relaxed">
              Personalized, online one-on-one sessions that turn confusion into confidence.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size="lg"
                className="bg-accent text-slate-800 hover:bg-yellow-400 text-lg px-8 py-4 h-auto shadow-lg"
                onClick={scrollToContact}
              >
                <Play className="w-5 h-5 mr-2" />
                Book Your Free 30-Min Trial
              </Button>
              <Button 
                size="lg"
                variant="outline"
                className="bg-white/20 text-white border-white/30 hover:bg-white/30 text-lg px-8 py-4 h-auto backdrop-blur-sm"
              >
                <Video className="w-5 h-5 mr-2" />
                Watch Demo
              </Button>
            </div>
            <div className="mt-8 flex items-center justify-center lg:justify-start space-x-4 text-blue-100">
              <div className="flex items-center">
                <Star className="w-4 h-4 text-accent mr-1 fill-current" />
                <span className="font-semibold">4.9/5</span>
              </div>
              <span>•</span>
              <span>200+ happy students</span>
              <span>•</span>
              <span>Free trial guaranteed</span>
            </div>
          </div>
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Professional math tutor with whiteboard" 
              className="rounded-2xl shadow-2xl w-full animate-pulse"
            />
            <div className="absolute -top-4 -right-4 bg-accent text-slate-800 p-3 rounded-full shadow-lg animate-bounce">
              <Star className="w-6 h-6" />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-secondary text-white p-3 rounded-full shadow-lg">
              <Star className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}