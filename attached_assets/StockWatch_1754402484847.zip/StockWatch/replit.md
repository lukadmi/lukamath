# LukaMath - Online Math Tutoring Platform

## Overview

LukaMath is a modern web application designed as a marketing and booking platform for online math tutoring services. The application serves as a professional landing page for high school math tutoring, featuring services like algebra, geometry, trigonometry, and SAT/ACT preparation. It includes a contact form system for booking tutoring sessions, managing student inquiries, and a comprehensive resources section with math study guides and blog content.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Framework**: Tailwind CSS with shadcn/ui component library for consistent, accessible UI components
- **Routing**: Wouter for lightweight client-side routing with multi-page support
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation for type-safe form processing
- **Design System**: Custom design tokens with CSS variables, supporting light/dark themes
- **Content Management**: Static blog content with rich text formatting and categorization

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints for contact form submission and data retrieval
- **Middleware**: Custom logging middleware for API request tracking
- **Error Handling**: Centralized error handling with proper HTTP status codes

### Data Storage Solutions
- **Development**: In-memory storage using Map data structure
- **Production Ready**: Drizzle ORM configured for PostgreSQL integration
- **Database Schema**: Contacts table with fields for name, email, phone, subject, message, and timestamps
- **Type Safety**: Zod schemas for runtime validation and TypeScript type inference

### Authentication and Authorization
- Currently implements basic session handling infrastructure with connect-pg-simple
- No authentication required for the contact form functionality
- Admin endpoints exist but are not protected (suitable for development/demo)

### External Service Integrations
- **Database**: Neon Database (serverless PostgreSQL) configured via DATABASE_URL
- **Development Tools**: Replit-specific plugins for development environment
- **Build Process**: Vite for frontend bundling, esbuild for server-side compilation
- **Fonts**: Google Fonts (Inter) for typography

### Key Design Patterns
- **Separation of Concerns**: Clear separation between client, server, and shared code
- **Type Safety**: End-to-end TypeScript with shared schemas between frontend and backend
- **Component Architecture**: Reusable UI components with consistent styling patterns
- **Responsive Design**: Mobile-first approach with Tailwind CSS breakpoints
- **Error Boundaries**: Proper error handling and user feedback through toast notifications
- **Content Structure**: Organized blog content with metadata, categorization, and featured post system
- **Navigation Patterns**: Mixed navigation supporting both section scrolling and route-based pages

## External Dependencies

### Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React router
- **react-hook-form**: Form state management and validation
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### UI and Styling
- **@radix-ui/react-***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Utility for handling component variants
- **clsx**: Conditional className utility

### Database and Validation
- **drizzle-orm**: Type-safe SQL ORM
- **drizzle-zod**: Integration between Drizzle and Zod schemas
- **@neondatabase/serverless**: Neon database client for serverless environments
- **zod**: Runtime type validation and schema definition

### Development Tools
- **vite**: Fast build tool and development server
- **tsx**: TypeScript execution for Node.js
- **@replit/vite-plugin-***: Replit-specific development enhancements

### Server Dependencies
- **express**: Web application framework
- **connect-pg-simple**: PostgreSQL session store (configured but not actively used)
- **date-fns**: Date utility library for handling timestamps